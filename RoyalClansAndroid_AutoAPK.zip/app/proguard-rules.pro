# Royal Clans Android release rules

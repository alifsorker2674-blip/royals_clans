# Automatic APK build

## 1. Put this project in GitHub

Upload the contents of this ZIP to a GitHub repository.

## 2. Set the Royal Clans URL

Before running the workflow, edit:

`app/src/main/java/com/royalclans/tournament/MainActivity.kt`

Change:

`https://YOUR-ROYAL-CLANS-DOMAIN.example`

to the real deployed HTTPS URL of the Royal Clans client.

## 3. Build

Open GitHub -> your repository -> Actions -> **Build Royal Clans APK** -> **Run workflow**.

After it finishes, open the workflow run and download:

`RoyalClans-debug-APK`

Inside it is:

`app-debug.apk`

This is a debug APK for testing.

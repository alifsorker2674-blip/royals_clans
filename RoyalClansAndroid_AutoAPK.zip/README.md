# Royal Clans Android

Android Studio wrapper for the uploaded `FF tournament/royal-clans` Next.js client.

## What this project does

The existing Royal Clans client is a Next.js web application. This Android project packages the deployed client inside a native Android WebView, so the same login, tournaments, quick match, wallet, leaderboard, profile and other client routes can be used from Android.

## Before building

1. Deploy `FF tournament/royal-clans` to a public HTTPS URL.
2. Make sure the Royal Clans frontend has the correct `NEXT_PUBLIC_API_URL`.
3. Make sure the backend CORS configuration (`CLIENT_URLS`) allows the deployed Royal Clans frontend.
4. Open `app/src/main/java/com/royalclans/tournament/MainActivity.kt`.
5. Replace `CLIENT_URL` with the deployed Royal Clans URL.
6. Open this folder in Android Studio.
7. Let Gradle sync.
8. Run `assembleDebug` to create the APK.

## Important security note

Do NOT put the backend `.env`, MongoDB credentials, JWT secrets, VAPID private key, Discord webhook, or other server secrets into the Android app. The APK is client-side and can be inspected.

## Existing source

The original Royal Clans source is included under `web-source-reference/` for reference. It is not copied into the Android `app/src/main` directory because the current Next.js app is server/deployment based.

## Backend

The uploaded repository contains a separate Node/TypeScript backend under `server/`. The Android app talks to the Royal Clans frontend, and the frontend talks to that backend.

## APK output

After building:

`app/build/outputs/apk/debug/app-debug.apk`

For Play Store/release distribution, create a signed release build instead of distributing the debug APK.

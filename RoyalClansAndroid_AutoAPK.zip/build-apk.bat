@echo off
echo Open this project in Android Studio first and let Gradle sync.
echo Then run: gradlew.bat assembleDebug
echo APK: app\build\outputs\apk\debug\app-debug.apk
